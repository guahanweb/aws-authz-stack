export declare function validateToken(event: any): Promise<{
    isBase64Encoded: boolean;
    statusCode: number;
    body: string;
}>;
export declare function generateToken(event: any): Promise<{
    isBase64Encoded: boolean;
    statusCode: number;
    body: string;
}>;
//# sourceMappingURL=lambda.d.ts.map