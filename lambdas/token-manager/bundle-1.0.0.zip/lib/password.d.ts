export declare function genRandomString(length: number): string;
export declare function genSecretKey(length: number): string;
export declare function sha512(password: string, salt: string): {
    salt: string;
    passwordHash: string;
};
export declare function saltHashPassword(password: string, salt_length?: number): {
    salt: string;
    passwordHash: string;
};
export declare function validate(password: string, hash: string, salt: string): boolean;
export declare function encodeBasicAuth(user: string, pass: string): string;
export declare function decodeBasicAuth(token: string): {
    user: string;
    pass: string;
};
//# sourceMappingURL=password.d.ts.map