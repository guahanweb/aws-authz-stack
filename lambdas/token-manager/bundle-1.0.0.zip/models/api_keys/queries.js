"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getApiKeyByOrganization = exports.deleteApiKey = exports.updateApiKey = exports.getApiKey = exports.createKeyPair = exports.initialize = void 0;
const utils_1 = require("../utils");
const SK = "API_KEY";
let TableName;
let initialized = false;
function assertInitialized() {
    if (!initialized) {
        throw new Error("cannot operate on the model without first initializing");
    }
}
function initialize(tableName) {
    TableName = tableName;
    initialized = true;
}
exports.initialize = initialize;
function createKeyPair(data) {
    assertInitialized();
    const created = (0, utils_1.getInsertDate)();
    const { org, access_key } = data;
    data.pk = access_key;
    data.sk = SK;
    data.pData = `${org}#${created}`;
    data.created = created;
    const params = (0, utils_1.createItem)(data, TableName);
    params.Item = data;
    return params;
}
exports.createKeyPair = createKeyPair;
function getApiKey(access_key) {
    assertInitialized();
    return (0, utils_1.getItemByPK)(access_key, SK, TableName);
}
exports.getApiKey = getApiKey;
function updateApiKey(access_key, data) {
    assertInitialized();
    return Object.assign(Object.assign({}, getApiKey(access_key)), (0, utils_1.buildUpdateExpression)(data));
}
exports.updateApiKey = updateApiKey;
function deleteApiKey(access_key) {
    assertInitialized();
    return (0, utils_1.deleteItemByPK)(access_key, SK, TableName);
}
exports.deleteApiKey = deleteApiKey;
function getApiKeyByOrganization(org, limit = 100) { }
exports.getApiKeyByOrganization = getApiKeyByOrganization;
