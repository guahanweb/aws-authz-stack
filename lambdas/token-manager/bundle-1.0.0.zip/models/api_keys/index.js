"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAccessToken = exports.getKeyPair = exports.generateKeyPair = void 0;
const pw = __importStar(require("../../lib/password"));
const queries = __importStar(require("./queries"));
const tokens = __importStar(require("../tokens"));
function cleanReturn(data, removeAuth = false) {
    data.access_key = data.pk;
    delete data.pk;
    delete data.sk;
    delete data.pData;
    delete data.sData;
    if (removeAuth) {
        delete data.salt;
        delete data.passwordHash;
    }
    return data;
}
function generateKeyPair(dynamo, options) {
    return __awaiter(this, void 0, void 0, function* () {
        queries.initialize(dynamo.table("apiKeySchema"));
        // key pair
        const access_key = pw.genRandomString(20).toUpperCase();
        const access_secret = pw.genSecretKey(40);
        // additional information (will be attached to tokens)
        const client_id = (options && options.client) || null;
        const org = (options && options.organization) || null;
        let scopes = (options && options.scopes) || "";
        if (scopes instanceof Array) {
            scopes = scopes.join(",");
        }
        try {
            if (!client_id || !org) {
                throw new Error("access key pair requires client_id and org");
            }
            const { passwordHash, salt } = pw.saltHashPassword(access_secret);
            const data = {
                org,
                client_id,
                scopes,
                access_key,
                passwordHash,
                salt,
            };
            const params = queries.createKeyPair(data);
            yield dynamo.client.put(params);
            return cleanReturn(Object.assign(Object.assign({}, params.Item), { access_secret }), true);
        }
        catch (err) {
            throw err;
        }
    });
}
exports.generateKeyPair = generateKeyPair;
function getKeyPair(dynamo, access_key) {
    return __awaiter(this, void 0, void 0, function* () {
        queries.initialize(dynamo.table("apiKeySchema"));
        try {
            const params = queries.getApiKey(access_key);
            const result = yield dynamo.client.get(params);
            return cleanReturn(result.Item);
        }
        catch (err) {
            console.error(err);
            throw err;
        }
    });
}
exports.getKeyPair = getKeyPair;
function createAccessToken(dynamo, access_key, access_secret) {
    return __awaiter(this, void 0, void 0, function* () {
        queries.initialize(dynamo.table("apiKeySchema"));
        const key = yield getKeyPair(dynamo, access_key);
        const { passwordHash, salt } = key;
        if (!pw.validate(access_secret, passwordHash, salt)) {
            throw new Error("invalid credentials provided");
        }
        const tok = yield tokens.generateToken(dynamo, {
            client_id: key.client_id,
            org: key.og,
            scopes: key.scopes,
            type: "BEARER",
        });
        return tok;
    });
}
exports.createAccessToken = createAccessToken;
