export declare function generateKeyPair(dynamo: any, options: any): Promise<any>;
export declare function getKeyPair(dynamo: any, access_key: string): Promise<any>;
export declare function createAccessToken(dynamo: any, access_key: string, access_secret: string): Promise<any>;
//# sourceMappingURL=index.d.ts.map