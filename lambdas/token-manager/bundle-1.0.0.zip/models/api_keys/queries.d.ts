export declare function initialize(tableName: string): void;
export declare function createKeyPair(data: any): {
    TableName: string;
    Item: any;
};
export declare function getApiKey(access_key: string): {
    TableName: string;
    Key: {
        pk: string;
        sk: string;
    };
};
export declare function updateApiKey(access_key: string, data: any): any;
export declare function deleteApiKey(access_key: string): {
    TableName: string;
    Key: {
        pk: string;
        sk: string;
    };
};
export declare function getApiKeyByOrganization(org: string, limit?: number): void;
//# sourceMappingURL=queries.d.ts.map