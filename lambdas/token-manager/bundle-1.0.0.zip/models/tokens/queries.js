"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAccessToken = exports.createToken = exports.initialize = void 0;
const utils_1 = require("../utils");
const SK = "TOKEN";
let TableName;
let initialized = false;
function assertInitialized() {
    if (!initialized) {
        throw new Error("cannot operate on the model without first initializing");
    }
}
function initialize(tableName) {
    TableName = tableName;
    initialized = true;
}
exports.initialize = initialize;
function createToken(data) {
    assertInitialized();
    const { access_token, org } = data;
    const created = (0, utils_1.getInsertDate)();
    data.pk = access_token;
    data.sk = SK;
    data.pData = `${org}#${created}`;
    data.created = created;
    const params = (0, utils_1.createItem)(data, TableName);
    params.Item = data;
    return params;
}
exports.createToken = createToken;
function getAccessToken(token) {
    assertInitialized();
    return (0, utils_1.getItemByPK)(token, SK, TableName);
}
exports.getAccessToken = getAccessToken;
