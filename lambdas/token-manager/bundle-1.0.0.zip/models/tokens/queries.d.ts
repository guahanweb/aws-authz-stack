export declare function initialize(tableName: string): void;
export declare function createToken(data: any): any;
export declare function getAccessToken(token: string): {
    TableName: string;
    Key: {
        pk: string;
        sk: string;
    };
};
//# sourceMappingURL=queries.d.ts.map