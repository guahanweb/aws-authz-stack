"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAccessToken = exports.generateToken = void 0;
const password_1 = require("../../lib/password");
const queries = __importStar(require("./queries"));
function cleanReturn(data) {
    data.access_token = data.pk;
    delete data.sk;
    delete data.pData;
    delete data.sData;
    // seconds until expiration
    data.expires_in = data.ttl - Math.floor(Date.now() / 1000);
    return data;
}
function generateToken(dynamo, data, expires_in = 900) {
    return __awaiter(this, void 0, void 0, function* () {
        queries.initialize(dynamo.table("authTokenSchema"));
        const ttl = Math.round((Date.now() / 1000) + expires_in);
        const access_token = (0, password_1.genRandomString)(32);
        // attach all the relevant info to tokens
        const { client_id, org, scopes, type } = data;
        const token = {
            access_token,
            client_id,
            org,
            scopes,
            type,
            ttl,
        };
        const params = queries.createToken(token);
        yield dynamo.client.put(params);
        return cleanReturn(params.Item);
    });
}
exports.generateToken = generateToken;
function getAccessToken(dynamo, tok) {
    return __awaiter(this, void 0, void 0, function* () {
        queries.initialize(dynamo.table("authTokenSchema"));
        const params = queries.getAccessToken(tok);
        const response = yield dynamo.client.get(params);
        const Item = response && response.Item;
        return Item ? cleanReturn(Item) : null;
    });
}
exports.getAccessToken = getAccessToken;
