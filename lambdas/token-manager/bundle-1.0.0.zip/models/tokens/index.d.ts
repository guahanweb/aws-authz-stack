export declare function generateToken(dynamo: any, data: any, expires_in?: number): Promise<any>;
export declare function getAccessToken(dynamo: any, tok: string): Promise<any>;
//# sourceMappingURL=index.d.ts.map