export declare function createItem(data: any, tableName: string): {
    TableName: string;
    Item: any;
};
export declare function getItemByPK(pk: string, sk: string, tableName: string): {
    TableName: string;
    Key: {
        pk: string;
        sk: string;
    };
};
export declare function deleteItemByPK(pk: string, sk: string, tableName: string): {
    TableName: string;
    Key: {
        pk: string;
        sk: string;
    };
};
export declare function getListByPK(pk: string, sk: string, limit: number, reverse: boolean, tableName: string): any;
export declare function getListBySK(sk: string, pData: string, limit: number, reverse: boolean, tableName: string): any;
export declare function buildUpdateExpression(data: any, ReturnValues?: string): any;
export declare function getInsertDate(): string;
//# sourceMappingURL=utils.d.ts.map