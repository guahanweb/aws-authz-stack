"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getInsertDate = exports.buildUpdateExpression = exports.getListBySK = exports.getListByPK = exports.deleteItemByPK = exports.getItemByPK = exports.createItem = void 0;
function createItem(data, tableName) {
    return {
        TableName: tableName,
        Item: data,
    };
}
exports.createItem = createItem;
function getItemByPK(pk, sk, tableName) {
    return {
        TableName: tableName,
        Key: { pk, sk },
    };
}
exports.getItemByPK = getItemByPK;
function deleteItemByPK(pk, sk, tableName) {
    return getItemByPK(pk, sk, tableName);
}
exports.deleteItemByPK = deleteItemByPK;
function getListByPK(pk, sk, limit, reverse, tableName) {
    let params = {
        TableName: tableName,
        KeyConditionExpression: "pk = :pk",
        ExpressionAttributeValues: {
            ":pk": pk
        },
        ScanIndexForward: !reverse,
        Limit: limit || 100
    };
    if (!!sk) {
        params.KeyConditionExpression += " and begins_with(sk, :sk)";
        params.ExpressionAttributeValues[":sk"] = sk;
    }
    return params;
}
exports.getListByPK = getListByPK;
function getListBySK(sk, pData, limit, reverse, tableName) {
    let params = {
        TableName: tableName,
        IndexName: "sk-pData",
        KeyConditionExpression: "sk = :sk",
        ExpressionAttributeValues: {
            ":sk": sk,
        },
        ScanIndexForward: !reverse,
        Limit: limit,
    };
    if (!!pData) {
        params.KeyConditionExpression += " and begins_with(pData, :pData)";
        params.ExpressionAttributeValues[":pData"] = pData;
    }
    return params;
}
exports.getListBySK = getListBySK;
function buildUpdateExpression(data, ReturnValues = "ALL_NEW") {
    let params = {
        UpdateExpression: "",
        ExpressionAttributeNames: {},
        ExpressionAttributeValues: {},
        ReturnValues,
    };
    let keys = "abcdefghijklmnopqrstuvwxyz", i = 0, updates = [], k, name, val;
    Object.keys(data).forEach(key => {
        k = keys[i++];
        name = `#${k}`;
        val = `:${k}`;
        params.ExpressionAttributeNames[name] = key;
        params.ExpressionAttributeValues[val] = data[key];
        updates.push(`${name} = ${val}`);
    });
    params.UpdateExpression = "set " + updates.join(", ");
    return params;
}
exports.buildUpdateExpression = buildUpdateExpression;
function getInsertDate() {
    return (new Date).toISOString();
}
exports.getInsertDate = getInsertDate;
