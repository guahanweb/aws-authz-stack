declare const _default: {
    env: any;
    appname: any;
    dynamo: {
        version: any;
        endpoint: any;
        region: any;
        tablePrefix: any;
    };
};
export default _default;
//# sourceMappingURL=config.d.ts.map