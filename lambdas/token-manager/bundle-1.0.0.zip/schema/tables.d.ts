declare const _default: {
    apiKeySchema: {
        AttributeDefinitions: {
            AttributeName: string;
            AttributeType: string;
        }[];
        KeySchema: {
            AttributeName: string;
            KeyType: string;
        }[];
        ProvisionedThroughput: {
            ReadCapacityUnits: number;
            WriteCapacityUnits: number;
        };
        GlobalSecondaryIndexes: {
            IndexName: string;
            KeySchema: {
                AttributeName: string;
                KeyType: string;
            }[];
            ProvisionedThroughput: {
                ReadCapacityUnits: number;
                WriteCapacityUnits: number;
            };
            Projection: {
                ProjectionType: string;
            };
        }[];
    };
    authTokenSchema: {
        AttributeDefinitions: {
            AttributeName: string;
            AttributeType: string;
        }[];
        KeySchema: {
            AttributeName: string;
            KeyType: string;
        }[];
        ProvisionedThroughput: {
            ReadCapacityUnits: number;
            WriteCapacityUnits: number;
        };
        TimeToLiveSpecification: {
            AttributeName: string;
            Enabled: boolean;
        };
    };
};
export default _default;
//# sourceMappingURL=tables.d.ts.map