"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateToken = exports.validateToken = void 0;
const config_1 = __importDefault(require("./config"));
const tables_1 = __importDefault(require("./schema/tables"));
const common_dynamodb_1 = require("@careacademy/common-dynamodb");
const pw = __importStar(require("./lib/password"));
const keys = __importStar(require("./models/api_keys"));
const tokens = __importStar(require("./models/tokens"));
function ok(data) {
    return {
        isBase64Encoded: false,
        statusCode: 200,
        body: JSON.stringify(data),
    };
}
function unauthorized() {
    return {
        isBase64Encoded: false,
        statusCode: 401,
        body: JSON.stringify({
            error: "Unauthorized",
        })
    };
}
function connect() {
    console.log("CONFIG:", JSON.stringify(config_1.default.dynamo));
    const dynamo = new common_dynamodb_1.DynamoClient({
        apiVersion: config_1.default.dynamo.version,
        endpoint: config_1.default.dynamo.endpoint,
        region: config_1.default.dynamo.region,
        prefix: config_1.default.dynamo.tablePrefix,
    });
    dynamo.loadSchema(tables_1.default);
    return dynamo;
}
function parseAuthHeader({ headers }, use_basic = false) {
    let token = null;
    for (let h in headers) {
        if (headers.hasOwnProperty(h) && h.toLowerCase() === "authorization") {
            const r = use_basic ? /^Basic\s+/i : /^Bearer\s+/i;
            token = headers[h].replace(r, "");
        }
    }
    return token;
}
function parseQueryString({ queryStringParameters }, param) {
    const value = queryStringParameters && queryStringParameters[param];
    return value || null;
}
function validateToken(event) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            console.log(JSON.stringify(event));
            const dynamo = connect();
            const data = parseQueryString(event, "token");
            const token = yield tokens.getAccessToken(dynamo, data);
            return token
                ? ok({ token })
                : unauthorized();
        }
        catch (err) {
            console.error("[ERR:generated]", err.message);
            return unauthorized();
        }
    });
}
exports.validateToken = validateToken;
function generateToken(event) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const dynamo = connect();
            const authorization = parseAuthHeader(event, true);
            if (authorization === null)
                throw new Error("no authorization provided");
            const credentials = pw.decodeBasicAuth(authorization);
            const token = yield keys.createAccessToken(dynamo, credentials.user, credentials.pass); // createAccessToken(credentials.user, credentials.pass);
            return ok({ token });
        }
        catch (err) {
            console.error(`[ERROR:generate] ${err.message}`);
            return unauthorized();
        }
    });
}
exports.generateToken = generateToken;
