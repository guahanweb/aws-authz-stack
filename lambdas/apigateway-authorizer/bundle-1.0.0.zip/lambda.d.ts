declare function handler(event: any, context: any): Promise<any>;
export { handler };
//# sourceMappingURL=lambda.d.ts.map