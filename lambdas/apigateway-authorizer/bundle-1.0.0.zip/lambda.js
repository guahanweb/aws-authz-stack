"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lambda_utils_1 = require("@careacademy/lambda-utils");
const config = {
    endpoint: loadFromEnv("AUTH_ENDPOINT", null),
    allowedScopes: loadScopesArray(),
};
function handler(event, context) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const token = event.authorizationToken;
            const valid = token.match(/^bearer\s+(.*)$/i);
            // we need to be sure we have only the token from the header
            if (!valid)
                return "Unauthorized";
            const response = yield (0, lambda_utils_1.fetchValidation)(config.endpoint, valid[1]);
            // invalid token, so 401
            if (response.token === null)
                return "Unauthorized";
            // if configured with allowed scopes, assure the token has the right one
            if (config.allowedScopes && config.allowedScopes.length) {
                const hasScopes = response.token.scopes.some((scope) => config.allowedScopes.includes(scope));
                if (!hasScopes) {
                    // we will actively deny due to missing scopes
                    return generatePolicy("user", "Deny", event.methodArn);
                }
            }
            // if we reach this point, we have a valid token, so allow
            return generatePolicy("user", "Allow", event.methodArn);
        }
        catch (err) {
            return "Unauthorized";
        }
    });
}
exports.handler = handler;
function generatePolicy(principalId, effect, resource) {
    const authResponse = { principalId };
    if (effect && resource) {
        const policyDocument = {
            Version: "2012-10-17",
            Statement: [],
        };
        const statementOne = {
            Action: "execute-api:Invoke",
            Effect: effect,
            Resource: resource,
        };
        policyDocument.Statement[0] = statementOne;
        authResponse.policyDocument = policyDocument;
    }
    // Optional output with custom properties of the String, Number or Boolean type
    authResponse.context = {};
    return authResponse;
}
function loadFromEnv(name, defaultValue) {
    const value = process.env && process.env[name];
    return value || defaultValue;
}
function loadScopesArray() {
    const scopes = loadFromEnv("AUTH_ALLOWED_SCOPES", "")
        .split(",")
        .filter((scope) => scope) // TODO: any filtering
        .map((scope) => scope.trim().toLowerCase());
    return scopes.length ? scopes : null;
}
